from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Account

class GeneralInfo(forms.ModelForm):
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'placeholder': 'Email'})
    )
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'placeholder': 'Username'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Password'})
    )
    password_confirmation = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'})
    )
    phone_number = forms.CharField(
        max_length=15, 
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Phone Number'})
    )
    role = forms.ChoiceField(
        choices=[(role, label) for role, label in Account.ROLE_LIST if role != 'Administrator'],
        widget=forms.Select(attrs={'placeholder': 'Select Role'})
    )

    class Meta:
        model = Account
        fields = ['username', 'email', 'password', 'password_confirmation', 'phone_number', 'role']

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password')
        password2 = cleaned_data.get('password_confirmation')

        if password1 and password2 and password1 != password2:
            self.add_error('password_confirmation', "Passwords don't match")

        return cleaned_data

class StudentSignUp(forms.Form):
    study_program = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Study Program'})
    )
    years_of_study = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'placeholder': 'Years of Study'})
    )
    gpa = forms.FloatField(
        required=False,
        widget=forms.NumberInput(attrs={'placeholder': 'GPA'})
    )

class FunderSignUp(forms.Form):
    organization_name = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Organization Name'})
    )
